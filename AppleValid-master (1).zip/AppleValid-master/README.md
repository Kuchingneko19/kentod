# Apple Email Checker

originally made with php but changed to a more powerful python language

## Requirement

 - Python 3

## How to run

install dependencies :

    pip install -r requirements.txt

run :

    python run.py

## Screenshot

![](screenshot/2.0.png)

## Video

https://www.twitch.tv/pwn0sec
